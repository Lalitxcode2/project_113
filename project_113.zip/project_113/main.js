function preload(){
    
}

function setup(){
    canvas = createCanvas(640,480);
    canvas.position(110,250);
    video = createCapture(VIDEO);
    video.hide();

    tint_color = "";
}

function apply_color(){
    tint_color = document.getElementById("color").value;
}

function draw(){
    image(video,0,0,640,480);
    tint(tint_color);
    circle(56, 56, 90, 90);
    circle(580 , 56, 90, 90);
    circle(56, 420, 90, 90);
    circle(580, 420, 90, 90);
    rect(575, 0, 20, 500);
    rect(48, 0, 20, 500);
}

function download(){
    save('mycolorpic.png');
}